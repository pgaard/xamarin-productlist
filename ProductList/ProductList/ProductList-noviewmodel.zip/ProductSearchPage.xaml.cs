﻿
namespace ProductList
{
    using System;
    using Xamarin.Forms;
    using System.Collections.ObjectModel;
    using System.Threading.Tasks;
    using Models;

    using ProductList.Services;

    public partial class ProductSearchPage : ContentPage
    {
        private readonly ProductService productService;
        private readonly PageService pageService;

        private ProductCollection productCollection;
        private int currentPage = 1;

        protected ObservableCollection<Product> ProductList;
        public ProductSearchPage()
        {
            this.productService = new ProductService();

            this.BindingContext = this;
            this.InitializeComponent();
        }

        private readonly BindableProperty isSearchingProperty = BindableProperty.Create(
            "IsSearching",
            typeof(bool),
            typeof(ProductSearchPage),
            false);

        public bool IsSearching
        {
            get
            {
                return (bool)GetValue(this.isSearchingProperty);
            }
            set
            {
                this.SetValue(this.isSearchingProperty, value);
            }
        }

        private readonly BindableProperty hitCount = BindableProperty.Create(
            "HitCount",
            typeof(int),
            typeof(ProductSearchPage),
            0);

        public int HitCount
        {
            get
            {
                return (int)GetValue(this.hitCount);
            }
            set
            {
                this.SetValue(this.hitCount, value);
            }
        }

        private async void Handle_Search(object sender, EventArgs e)
        {
            this.currentPage = 1;
            await this.LoadProducts(this.currentPage);
            this.ListView.ItemsSource = this.ProductList;
            this.HitCount = this.productCollection.pagination.totalItemCount;
        }

        private async Task LoadProducts(int page)
        {
            this.IsSearching = true;
            
            if (page == 1)
            {                
                this.productCollection = await this.productService.DoProductSearch(this.SearchBar.Text, page);  
            }
            else
            {
                var newProductCollection = await this.productService.DoProductSearch(this.SearchBar.Text, page);
                this.productCollection.products.AddRange(newProductCollection.products);
            }
            this.ProductList = new ObservableCollection<Product>(this.productCollection.products);
            this.ListView.ItemsSource = this.ProductList;
            if (page == 1)
            {
                this.ListView.ScrollTo(this.ProductList[0], ScrollToPosition.Start, false);
            }
            this.IsSearching = false;
        }

        private async void ListView_OnItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            if (e.SelectedItem == null)
            {
                return;
            }
            var product = e.SelectedItem as Product;
            await this.Navigation.PushAsync(new ProductDetail(product));
            this.ListView.SelectedItem = null;
        }

        private async void ListView_ItemAppearing(object sender, ItemVisibilityEventArgs e)
        {
            if (!this.IsSearching && this.ProductList != null && e.Item == this.ProductList[Math.Max(this.ProductList.Count - 4, 0)])
            {
                if (this.currentPage < this.productCollection.pagination.numberOfPages)
                {
                    this.currentPage++;
                    await this.LoadProducts(this.currentPage);
                }
            }
        }
    }
}
