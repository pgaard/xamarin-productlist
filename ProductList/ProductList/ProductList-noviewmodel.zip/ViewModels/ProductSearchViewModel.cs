﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductList.ViewModels
{
    using System.Collections.ObjectModel;

    using ProductList.Models;
    using ProductList.Services;

    public class ProductSearchViewModel : BaseViewModel
    {
        private readonly IProductService productService;
        private readonly IPageService pageService;

        private ProductCollection productCollection;
        private int currentPage = 1;

        protected ObservableCollection<Product> ProductList;

        public ProductSearchViewModel(IProductService productService, IPageService pageService)
        {
            this.productService = productService;
            this.pageService = pageService;
        }

    }
}
